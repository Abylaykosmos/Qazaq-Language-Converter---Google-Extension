const fromText = document.querySelector(".from-text"),
toText = document.querySelector(".to-text"),
exchageIcon = document.querySelector(".exchange"),
icons = document.querySelectorAll(".row i");
convertBtn = document.querySelector("#convert");
voiceinputBtn = document.querySelector("#voiceinput");

copyfrom= document.querySelector("#from");
copyto= document.querySelector("#to");

let translateFrom = document.getElementById("option1").value;
let translateTo = document.getElementById("option2").value;


document.getElementById("option1").addEventListener("click", e => {
   var value = e.target.value
    var lat = "kz-KK"
    const isVisible = lat.includes(value)
    voiceinputBtn.classList.toggle("hide", !isVisible)

  })


convertBtn.addEventListener("click", () => {
    let text = fromText.value;
    console.log(text, document.getElementById("option1").value, document.getElementById("option2").value);

    if (document.getElementById("option1").value == "kz-QQ" && document.getElementById("option2").value == "kz-KK") {
        toText.value = convert_to_kaz(text)
    }
    else if (document.getElementById("option1").value == "kz-KK" && document.getElementById("option2").value == "kz-QQ") {
        toText.value = convert_to_lat(text)
    }
    else if (document.getElementById("option1").value == "kz-KK" && document.getElementById("option2").value == "kz-KK") {
        toText.value = convert_to_kaz(text)
    }
    else {
        toText.value = convert_to_lat(text)
    }
});

exchageIcon.addEventListener("click", () => {
    let tempText = fromText.value,
    tempLang = document.getElementById("option1").value;
    fromText.value = toText.value;
    toText.value = tempText;
    document.getElementById("option1").value = document.getElementById("option2").value;
    document.getElementById("option2").value = tempLang;
});

copyfrom.addEventListener("click", () => {
  navigator.clipboard.writeText(fromText.value)

});

copyto.addEventListener("click", () => {
  navigator.clipboard.writeText(toText.value)

});

const SpeechRecognition = window.speechRecognition || window.webkitSpeechRecognition;
var recognition = new SpeechRecognition();

recognition.lang = 'kk-KZ';


voiceinputBtn.addEventListener('click', function () {
  recognition.start();

  //ProgressBar imitation
  fromText.value = "Записываем.";
  setTimeout(function (){
    fromText.value = "Записываем..";
    setTimeout(function (){
      fromText.value = "Записываем...";
    }, 500);
  }, 500);
})

//Retrieving the result of the voice input
recognition.onresult = function (e) {
  var transcript = e.results[0][0].transcript;
  fromText.value = transcript;
  if (translateFrom == "kz-QQ") {
    toText.value = convert_to_kaz(transcript)
  }
  else {
    toText.value = convert_to_lat(transcript)
  }
}

console.log(recognition.lang.value);
